load('config.js');

function run(url, page) {
    let target = page ? page : url;
    let doc = getDoc(target);
    if (!doc) {
        return Response.error('[list] Không tải được: ' + abs(target)
            + ' — HTTP ' + LAST_STATUS + '. Trình duyệt vào được mà app không vào nghĩa là IP đang bị gắn cờ, đợi 10-15 phút rồi thử lại.');
    }

    let books = parseList(doc);

    if (books.length === 0) {
        return Response.error('[list] Trang tải được nhưng không thấy truyện nào: ' + abs(target)
            + ' — số thẻ <a>: ' + doc.select('a').size());
    }

    let next = null;
    doc.select('a').forEach(e => {
        if (next) {
            return;
        }
        let t = e.text();
        if (t && (t.indexOf('下一页') !== -1 || t.indexOf('下页') !== -1 || t.indexOf('下一頁') !== -1)) {
            let href = e.attr('href');
            if (href && href.indexOf('javascript') !== 0 && href !== '#') {
                next = abs(href);
            }
        }
    });

    return Response.success(books, next);
}

function execute(url, page) {
    try {
        return run(url, page);
    } catch (error) {
        let msg = '';
        try {
            msg = '' + error;
        } catch (e2) {
            msg = 'không đọc được nội dung lỗi';
        }
        return Response.error('[list] LỖI SCRIPT: ' + msg);
    }
}
