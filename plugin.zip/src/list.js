load('config.js');

function execute(url, page) {
    let target = page ? page : url;
    let doc = getDoc(target);
    if (!doc) {
        return Response.error('[list] Không tải được: ' + abs(target)
            + ' — nếu vừa mở nhiều truyện liên tiếp, 69shuba có thể đang chặn tạm thời. Đợi 1-2 phút rồi thử lại.');
    }

    let books = parseList(doc);

    if (books.length === 0) {
        return Response.error('[list] Trang tải được nhưng không thấy truyện nào: ' + abs(target)
            + ' — số thẻ <a>: ' + doc.select('a').size());
    }

    let next = null;
    doc.select('a').forEach(e => {
        if (next) {
            return;
        }
        let t = e.text();
        if (t && (t.indexOf('下一页') !== -1 || t.indexOf('下页') !== -1 || t.indexOf('下一頁') !== -1)) {
            let href = e.attr('href');
            if (href && href.indexOf('javascript') !== 0 && href !== '#') {
                next = abs(href);
            }
        }
    });

    return Response.success(books, next);
}
