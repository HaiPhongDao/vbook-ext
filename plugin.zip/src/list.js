load('config.js');

function execute(url, page) {
    let target = page ? page : url;
    let doc = getDoc(target);
    if (!doc) {
        return Response.error('Không tải được danh sách: ' + target);
    }

    let books = parseList(doc);

    // Tim link "trang sau" de load tiep
    let next = null;
    doc.select('a').forEach(e => {
        if (next) {
            return;
        }
        let t = e.text();
        if (t && (t.indexOf('下一页') !== -1 || t.indexOf('下页') !== -1)) {
            let href = e.attr('href');
            if (href && href.indexOf('javascript') !== 0) {
                next = abs(href);
            }
        }
    });

    return Response.success(books, next);
}
