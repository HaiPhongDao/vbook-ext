load('config.js');

function execute(url) {
    let id = bookId(url);
    if (!id) {
        return Response.error('Không nhận diện được ID truyện từ: ' + url);
    }

    let doc = getDoc('/book/' + id + '.htm');
    if (!doc) {
        return Response.error('Không tải được trang truyện. Kiểm tra BASE_URL trong config.js.');
    }

    let name = pickText(doc, [
        '.booknav2 > h1 > a',
        '.booknav2 h1',
        '.bookname h1',
        'h1'
    ]);

    let cover = pickAttr(doc, [
        '.bookimg2 img',
        '.bookimg img',
        '.imgbox img',
        'meta[property="og:image"]'
    ], 'src');
    if (!cover) {
        cover = pickAttr(doc, ['meta[property="og:image"]'], 'content');
    }

    let author = pickText(doc, [
        '.booknav2 > p:nth-child(2) > a',
        '.booknav2 p a',
        '.author a',
        '.booknav2 p'
    ]).replace(/^作者[:：]\s*/, '');

    let description = '';
    let intro = doc.select('.navtxt > p').first();
    if (intro && intro.html()) {
        description = intro.html();
    }
    if (!description) {
        description = pickText(doc, ['.navtxt', '.intro', '#intro']);
    }

    let detail = '';
    doc.select('.booknav2 > p').forEach(e => {
        let t = e.text();
        if (t && t.trim().length > 0) {
            detail += t.trim() + '<br>';
        }
    });

    let statusText = detail + ' ' + description;
    let ongoing = statusText.indexOf('完本') === -1 && statusText.indexOf('已完结') === -1;

    return Response.success({
        name: name,
        cover: cover,
        host: BASE_URL,
        author: author,
        description: description,
        detail: detail,
        ongoing: ongoing
    });
}
