// 69shuba doi domain rat thuong xuyen.
// Neu domain chet, sua dong duoi day roi cai lai extension.
let BASE_URL = 'https://www.69shuba.com';

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

// 69shuba doi domain lien tuc, va mot so domain bi ISP Viet Nam chan.
// Neu domain chinh khong vao duoc, tu chuyen sang cai khac.
let ALT_DOMAINS = [
    'https://www.69shuba.com',
    'https://69shuba.com',
    'https://www.69shu.com',
    'https://www.69shux.com',
    'https://69shux.com',
    'https://www.69xinshu.com',
    'https://69shuba.cx',
    'https://69shuba.pro'
];

// Bang ma chinh cua 69shuba. Dat san de moi trang chi tai DUNG MOT LAN.
// De trong thi script phai tai lai nhieu lan de do -> de bi site chan tam thoi.
let CHARSET = 'gb18030';

// Nho lai bang ma da do duoc trong phien lam viec nay
let DETECTED = '';

let UA = 'Mozilla/5.0 (Linux; Android 14; Poco X7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36';

// Dem ky tu loi ma (U+FFFD) de cham diem cach giai ma
function badCount(s) {
    if (!s || s.length === 0) {
        return 999999;
    }
    let m = s.match(/\uFFFD/g);
    return m ? m.length : 0;
}

// sleep() khong co tren moi ban vBook -> goi thang se lam chet ca script
function safeSleep(ms) {
    try {
        sleep(ms);
    } catch (error) {
    }
}

// Anh bia co the nam tren CDN khac domain -> chi noi tien to khi la duong dan tuong doi
function absImg(url) {
    if (!url) {
        return '';
    }
    if (url.indexOf('//') === 0) {
        return 'https:' + url;
    }
    if (url.indexOf('http') === 0) {
        return url;
    }
    return BASE_URL + (url.charAt(0) === '/' ? url : '/' + url);
}

let LAST_STATUS = 0;

// Nho trang thai trong phien: khoi phi thoi gian thu lai cach da biet la hong
let USE_BROWSER = false;
let BROWSER_DEAD = false;
// Server co tra loi HTTP hay khong (khac han voi chuyen trang do co ton tai)
let REACHED = false;
let ALT_TRIED = false;

// Header cang giong Chrome that cang it bi chan
function browserHeaders() {
    return {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9,vi;q=0.8,en;q=0.7',
        'Referer': BASE_URL + '/',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1'
    };
}

function fetchText(full, charset) {
    try {
        let response = fetch(full, {
            method: 'GET',
            headers: browserHeaders()
        });
        if (!response) {
            return null;
        }
        try {
            LAST_STATUS = response.status;
        } catch (error) {
        }
        REACHED = true;
        if (!response.ok) {
            return null;
        }
        return response.text(charset);
    } catch (error) {
        return null;
    }
}

// fetch tran khong vuot duoc trang thu thach JS.
// Browser engine cua vBook chay duoc JS va dung chung cookie voi webview.
function browserDoc(full) {
    let browser = null;
    try {
        browser = Engine.newBrowser();
        try {
            browser.setUserAgent(UserAgent.android());
        } catch (error) {
        }
        let doc = browser.launch(full, 12000);
        try {
            browser.close();
        } catch (error) {
        }
        return doc ? doc : null;
    } catch (error) {
        try {
            if (browser) {
                browser.close();
            }
        } catch (e2) {
        }
        return null;
    }
}

function pathOf(url) {
    if (!url) {
        return '/';
    }
    if (url.indexOf('http') !== 0) {
        return url.charAt(0) === '/' ? url : '/' + url;
    }
    let m = url.match(/^https?:\/\/[^\/]+(\/.*)?$/i);
    return (m && m[1]) ? m[1] : '/';
}

// Giai ma mot lan. Chi tai lai khi giai ma HONG, khong tai lai khi mang hong.
function decodeAt(full) {
    let order = [];
    if (DETECTED) {
        order.push(DETECTED);
    }
    if (CHARSET && order.indexOf(CHARSET) === -1) {
        order.push(CHARSET);
    }
    if (order.indexOf('utf-8') === -1) {
        order.push('utf-8');
    }

    let first = fetchText(full, order[0]);
    // null = khong ket noi duoc. Thu bang ma khac cung vo ich -> dung ngay.
    if (first === null) {
        return null;
    }
    if (badCount(first) === 0) {
        DETECTED = order[0];
        return first;
    }

    // Tai duoc nhung chu bi loi -> luc nay moi dang thu bang ma khac
    let best = first;
    let bestBad = badCount(first);
    let bestCs = order[0];

    for (let i = 1; i < order.length; i++) {
        let t = fetchText(full, order[i]);
        if (t === null) {
            break;
        }
        let bad = badCount(t);
        if (bad < bestBad) {
            best = t;
            bestBad = bad;
            bestCs = order[i];
        }
        if (bad === 0) {
            break;
        }
    }

    DETECTED = bestCs;
    return best;
}

function tryBrowser(full) {
    if (BROWSER_DEAD) {
        return null;
    }
    let doc = browserDoc(full);
    if (doc) {
        USE_BROWSER = true;
        return doc;
    }
    // Hong mot lan thi lan sau khoi thu, tranh cho 12 giay moi trang
    BROWSER_DEAD = true;
    return null;
}

function getDoc(url) {
    let path = pathOf(url);

    if (USE_BROWSER) {
        let d = browserDoc(BASE_URL + path);
        if (d) {
            return d;
        }
        USE_BROWSER = false;
    }

    REACHED = false;
    let text = decodeAt(BASE_URL + path);
    if (text !== null) {
        try {
            return Html.parse(text);
        } catch (error) {
        }
    }

    // Server tra ve 404/410 = server song, chi la trang do khong ton tai.
    // Dung ngay, khong kich hoat day du phong ton thoi gian.
    if (REACHED && (LAST_STATUS === 404 || LAST_STATUS === 410)) {
        return null;
    }

    let doc = tryBrowser(BASE_URL + path);
    if (doc) {
        return doc;
    }

    // Chi quet domain du phong MOT LAN moi phien
    if (!ALT_TRIED) {
        ALT_TRIED = true;
        for (let i = 0; i < ALT_DOMAINS.length; i++) {
            if (ALT_DOMAINS[i] === BASE_URL) {
                continue;
            }
            let alt = ALT_DOMAINS[i];
            let t = fetchText(alt + path, DETECTED ? DETECTED : CHARSET);
            if (t !== null) {
                console.log('[net] Chuyển sang domain: ' + alt);
                BASE_URL = alt;
                try {
                    return Html.parse(t);
                } catch (error) {
                    return null;
                }
            }
        }
    }

    return null;
}

// Lay ID truyen tu bat ky dang url nao: /book/123.htm hoac /txt/123/456
function bookId(url) {
    let m = url.match(/\/book\/(\d+)/) || url.match(/\/txt\/(\d+)/);
    return m ? m[1] : null;
}

// Thu lan luot cac selector, tra ve cai dau tien co noi dung
function pickText(doc, selectors) {
    for (let i = 0; i < selectors.length; i++) {
        let el = doc.select(selectors[i]);
        if (el) {
            let t = el.first().text();
            if (t && t.trim().length > 0) {
                return t.trim();
            }
        }
    }
    return '';
}

function pickAttr(doc, selectors, attr) {
    for (let i = 0; i < selectors.length; i++) {
        let el = doc.select(selectors[i]);
        if (el) {
            let v = el.first().attr(attr);
            if (v && v.length > 0) {
                return absImg(v);
            }
        }
    }
    return '';
}

// Gom danh sach truyen tu bat ky trang liet ke nao.
// Bam vao link /book/<id> nen khong phu thuoc vao class cua theme.
function parseList(doc) {
    // Tren trang liet ke, moi truyen thuong co nhieu the <a>:
    //  - mot the boc anh bia, co the tro toi /book/<id>.htm HOAC /txt/<id>/
    //  - mot the chua ten truyen, tro toi /book/<id>.htm
    //  - cac the chuong moi nhat, tro toi /txt/<id>/<chapid>
    // Gom tat ca theo ID, nhung CHI lay ten tu link /book/ de khoi dinh nham ten chuong.
    let map = {};
    let order = [];

    function slot(id) {
        if (!map[id]) {
            map[id] = {name: '', cover: ''};
            order.push(id);
        }
        return map[id];
    }

    function grabCover(e, id) {
        let img = e.select('img');
        if (!img) {
            return;
        }
        let src = img.attr('data-original');
        if (!src) {
            src = img.attr('data-src');
        }
        if (!src) {
            src = img.attr('data-echo');
        }
        if (!src) {
            src = img.attr('src');
        }
        if (src && !slot(id).cover) {
            slot(id).cover = absImg(src);
        }
    }

    // Vong 1: link /book/<id> -> ten + anh bia
    doc.select('a[href*="/book/"]').forEach(e => {
        let href = e.attr('href');
        if (!href) {
            return;
        }
        let m = href.match(/\/book\/(\d+)/);
        if (!m) {
            return;
        }
        let id = m[1];
        grabCover(e, id);
        let t = e.text();
        t = t ? t.trim() : '';
        if (t.length > slot(id).name.length) {
            slot(id).name = t;
        }
    });

    // Vong 2: link /txt/<id> -> chi lay anh bia
    doc.select('a[href*="/txt/"]').forEach(e => {
        let href = e.attr('href');
        if (!href) {
            return;
        }
        let m = href.match(/\/txt\/(\d+)/);
        if (!m) {
            return;
        }
        grabCover(e, m[1]);
    });

    let books = [];
    order.forEach(id => {
        if (map[id].name.length === 0) {
            return;
        }
        books.push({
            name: map[id].name,
            link: BASE_URL + '/book/' + id + '.htm',
            host: BASE_URL,
            cover: map[id].cover,
            description: ''
        });
    });

    return books;
}
