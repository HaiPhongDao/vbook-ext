// 69shuba doi domain rat thuong xuyen.
// Neu domain chet, sua dong duoi day roi cai lai extension.
let BASE_URL = 'https://www.69shuba.com';

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

// Bang ma uu tien. De trong de tu do.
// gb18030 la sieu tap cua gbk/gb2312 nen dung cai nay la du.
let CHARSET = '';

let UA = 'Mozilla/5.0 (Linux; Android 14; Poco X7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36';

// Dem ky tu loi ma (U+FFFD) de cham diem tung cach giai ma
function badCount(s) {
    if (!s || s.length === 0) {
        return 999999;
    }
    let m = s.match(/\uFFFD/g);
    return m ? m.length : 0;
}

function abs(url) {
    if (!url) {
        return BASE_URL;
    }
    if (url.indexOf('http') !== 0) {
        return BASE_URL + (url.charAt(0) === '/' ? url : '/' + url);
    }
    return url.replace(/^https?:\/\/[^\/]+/i, BASE_URL);
}

// Anh bia co the nam tren CDN khac domain -> chi noi tien to khi la duong dan tuong doi
function absImg(url) {
    if (!url) {
        return '';
    }
    if (url.indexOf('//') === 0) {
        return 'https:' + url;
    }
    if (url.indexOf('http') === 0) {
        return url;
    }
    return BASE_URL + (url.charAt(0) === '/' ? url : '/' + url);
}

function getDoc(url) {
    let full = abs(url);
    let list = ['utf-8', 'gb18030'];
    if (CHARSET) {
        list = [CHARSET, 'utf-8', 'gb18030'];
    }

    let best = null;
    let bestBad = -1;

    for (let i = 0; i < list.length; i++) {
        let response = fetch(full, {
            method: 'GET',
            headers: {
                'User-Agent': UA,
                'Referer': BASE_URL + '/'
            }
        });
        if (!response.ok) {
            continue;
        }

        let text = response.text(list[i]);
        let bad = badCount(text);

        if (best === null || bad < bestBad) {
            best = text;
            bestBad = bad;
        }
        // Giai ma sach hoan toan -> khoi thu tiep
        if (bad === 0) {
            break;
        }
    }

    if (best === null) {
        return null;
    }
    return Html.parse(best);
}

// Lay ID truyen tu bat ky dang url nao: /book/123.htm hoac /txt/123/456
function bookId(url) {
    let m = url.match(/\/book\/(\d+)/) || url.match(/\/txt\/(\d+)/);
    return m ? m[1] : null;
}

// Thu lan luot cac selector, tra ve cai dau tien co noi dung
function pickText(doc, selectors) {
    for (let i = 0; i < selectors.length; i++) {
        let el = doc.select(selectors[i]);
        if (el) {
            let t = el.first().text();
            if (t && t.trim().length > 0) {
                return t.trim();
            }
        }
    }
    return '';
}

function pickAttr(doc, selectors, attr) {
    for (let i = 0; i < selectors.length; i++) {
        let el = doc.select(selectors[i]);
        if (el) {
            let v = el.first().attr(attr);
            if (v && v.length > 0) {
                return absImg(v);
            }
        }
    }
    return '';
}

// Gom danh sach truyen tu bat ky trang liet ke nao.
// Bam vao link /book/<id> nen khong phu thuoc vao class cua theme.
function parseList(doc) {
    // Tren trang liet ke, moi truyen thuong co nhieu the <a>:
    //  - mot the boc anh bia, co the tro toi /book/<id>.htm HOAC /txt/<id>/
    //  - mot the chua ten truyen, tro toi /book/<id>.htm
    //  - cac the chuong moi nhat, tro toi /txt/<id>/<chapid>
    // Gom tat ca theo ID, nhung CHI lay ten tu link /book/ de khoi dinh nham ten chuong.
    let map = {};
    let order = [];

    function slot(id) {
        if (!map[id]) {
            map[id] = {name: '', cover: ''};
            order.push(id);
        }
        return map[id];
    }

    function grabCover(e, id) {
        let img = e.select('img');
        if (!img) {
            return;
        }
        let src = img.attr('data-original');
        if (!src) {
            src = img.attr('data-src');
        }
        if (!src) {
            src = img.attr('data-echo');
        }
        if (!src) {
            src = img.attr('src');
        }
        if (src && !slot(id).cover) {
            slot(id).cover = absImg(src);
        }
    }

    // Vong 1: link /book/<id> -> ten + anh bia
    doc.select('a[href*="/book/"]').forEach(e => {
        let href = e.attr('href');
        if (!href) {
            return;
        }
        let m = href.match(/\/book\/(\d+)/);
        if (!m) {
            return;
        }
        let id = m[1];
        grabCover(e, id);
        let t = e.text();
        t = t ? t.trim() : '';
        if (t.length > slot(id).name.length) {
            slot(id).name = t;
        }
    });

    // Vong 2: link /txt/<id> -> chi lay anh bia
    doc.select('a[href*="/txt/"]').forEach(e => {
        let href = e.attr('href');
        if (!href) {
            return;
        }
        let m = href.match(/\/txt\/(\d+)/);
        if (!m) {
            return;
        }
        grabCover(e, m[1]);
    });

    let books = [];
    order.forEach(id => {
        if (map[id].name.length === 0) {
            return;
        }
        books.push({
            name: map[id].name,
            link: BASE_URL + '/book/' + id + '.htm',
            host: BASE_URL,
            cover: map[id].cover,
            description: ''
        });
    });

    return books;
}
