// 69shuba doi domain rat thuong xuyen.
// Neu domain chet, sua dong duoi day roi cai lai extension.
let BASE_URL = 'https://www.69shuba.com';

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

// '' = de jsoup tu doc meta charset.
// Neu chu bi loi ma (kieu "æµ‹è¯•"), doi thanh 'gbk'.
let CHARSET = '';

let UA = 'Mozilla/5.0 (Linux; Android 14; Poco X7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36';

function abs(url) {
    if (!url) {
        return BASE_URL;
    }
    if (url.indexOf('http') !== 0) {
        return BASE_URL + (url.charAt(0) === '/' ? url : '/' + url);
    }
    return url.replace(/^https?:\/\/[^\/]+/i, BASE_URL);
}

function getDoc(url) {
    let response = fetch(abs(url), {
        method: 'GET',
        headers: {
            'User-Agent': UA,
            'Referer': BASE_URL + '/'
        }
    });
    if (!response.ok) {
        return null;
    }
    return CHARSET ? response.html(CHARSET) : response.html();
}

// Lay ID truyen tu bat ky dang url nao: /book/123.htm hoac /txt/123/456
function bookId(url) {
    let m = url.match(/\/book\/(\d+)/) || url.match(/\/txt\/(\d+)/);
    return m ? m[1] : null;
}

// Thu lan luot cac selector, tra ve cai dau tien co noi dung
function pickText(doc, selectors) {
    for (let i = 0; i < selectors.length; i++) {
        let el = doc.select(selectors[i]);
        if (el) {
            let t = el.first().text();
            if (t && t.trim().length > 0) {
                return t.trim();
            }
        }
    }
    return '';
}

function pickAttr(doc, selectors, attr) {
    for (let i = 0; i < selectors.length; i++) {
        let el = doc.select(selectors[i]);
        if (el) {
            let v = el.first().attr(attr);
            if (v && v.length > 0) {
                return abs(v);
            }
        }
    }
    return '';
}

// Gom danh sach truyen tu bat ky trang liet ke nao.
// Bam vao link /book/<id> nen khong phu thuoc vao class cua theme.
function parseList(doc) {
    let books = [];
    let seen = {};

    doc.select('a[href*="/book/"]').forEach(e => {
        let href = e.attr('href');
        if (!href) {
            return;
        }
        let m = href.match(/\/book\/(\d+)/);
        if (!m) {
            return;
        }
        let id = m[1];
        let name = e.text();
        name = name ? name.trim() : '';
        if (name.length === 0 || seen[id]) {
            return;
        }
        seen[id] = true;
        books.push({
            name: name,
            link: BASE_URL + '/book/' + id + '.htm',
            host: BASE_URL,
            cover: '',
            description: ''
        });
    });

    return books;
}
