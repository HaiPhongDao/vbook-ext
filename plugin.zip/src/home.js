function execute() {
    return Response.success([
        {title: "首页", input: "/", script: "list.js"},
        {title: "最近更新", input: "/modules/article/toplist.php?sort=lastupdate", script: "list.js"},
        {title: "总点击榜", input: "/modules/article/toplist.php?sort=allvisit", script: "list.js"},
        {title: "总推荐榜", input: "/modules/article/toplist.php?sort=allvote", script: "list.js"},
        {title: "完本小说", input: "/modules/article/toplist.php?sort=goodnum", script: "list.js"}
    ]);
}
