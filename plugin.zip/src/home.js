load('config.js');

// Cac tab tinh du phong, dung khi khong doc duoc menu tren trang chu
function fallback() {
    return [
        {title: "新书推荐 [v11]", input: "/", script: "list.js"}
    ];
}

function execute() {
    try {
        return build();
    } catch (error) {
        // Tab luon phai hien ra, du co chuyen gi xay ra
        return Response.success(fallback());
    }
}

function build() {
    let doc = getDoc('/');
    if (!doc) {
        return Response.success(fallback());
    }

    let tabs = [];
    let featured = null;
    let seen = {};
    let skip = ['login', 'register', 'reg.php', 'bookcase', 'user', 'logout',
                'javascript', 'mailto', '#', 'help', 'about'];

    doc.select('a').forEach(e => {
        if (tabs.length >= 9) {
            return;
        }
        let href = e.attr('href');
        let title = e.text();
        if (!href || !title) {
            return;
        }
        title = title.trim();
        if (title.length === 0 || title.length > 8) {
            return;
        }

        let low = href.toLowerCase();
        for (let i = 0; i < skip.length; i++) {
            if (low.indexOf(skip[i]) !== -1) {
                return;
            }
        }
        // Chi lay link noi bo, bo qua link chuong va link truyen le
        if (/\/(txt|book)\//.test(href)) {
            return;
        }
        if (href.indexOf('http') === 0 && href.indexOf('69') === -1) {
            return;
        }
        if (href === '/' || href.length < 2) {
            return;
        }
        if (seen[href]) {
            return;
        }
        seen[href] = true;

        let tab = {title: title, input: href, script: "list.js"};

        // Tab de cu / truyen moi duoc dua len dau tien
        if (!featured && (title.indexOf('推荐') !== -1 || title.indexOf('新书') !== -1
                || title.indexOf('最新') !== -1 || title.indexOf('新书推荐') !== -1)) {
            featured = tab;
            return;
        }

        tabs.push(tab);
    });

    // Dat tab de cu len dau, khong tim thay thi dung trang chu lam tab dau
    if (featured) {
        featured.title = featured.title + ' [v11]';
        tabs.unshift(featured);
        tabs.push({title: "首页", input: "/", script: "list.js"});
    } else {
        tabs.unshift({title: "新书推荐 [v11]", input: "/", script: "list.js"});
    }

    return Response.success(tabs);
}
