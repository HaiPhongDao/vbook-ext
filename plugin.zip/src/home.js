load('config.js');

// Cac tab tinh du phong, dung khi khong doc duoc menu tren trang chu
function fallback() {
    return [
        {title: "首页 [v9]", input: "/", script: "list.js"}
    ];
}

function execute() {
    try {
        return build();
    } catch (error) {
        // Tab luon phai hien ra, du co chuyen gi xay ra
        return Response.success(fallback());
    }
}

function build() {
    let doc = getDoc('/');
    if (!doc) {
        return Response.success(fallback());
    }

    let tabs = [{title: "首页 [v9]", input: "/", script: "list.js"}];
    let seen = {};
    let skip = ['login', 'register', 'reg.php', 'bookcase', 'user', 'logout',
                'javascript', 'mailto', '#', 'help', 'about'];

    doc.select('a').forEach(e => {
        if (tabs.length >= 9) {
            return;
        }
        let href = e.attr('href');
        let title = e.text();
        if (!href || !title) {
            return;
        }
        title = title.trim();
        if (title.length === 0 || title.length > 8) {
            return;
        }

        let low = href.toLowerCase();
        for (let i = 0; i < skip.length; i++) {
            if (low.indexOf(skip[i]) !== -1) {
                return;
            }
        }
        // Chi lay link noi bo, bo qua link chuong va link truyen le
        if (/\/(txt|book)\//.test(href)) {
            return;
        }
        if (href.indexOf('http') === 0 && href.indexOf('69') === -1) {
            return;
        }
        if (href === '/' || href.length < 2) {
            return;
        }
        if (seen[href]) {
            return;
        }
        seen[href] = true;

        tabs.push({title: title, input: href, script: "list.js"});
    });

    return Response.success(tabs);
}
