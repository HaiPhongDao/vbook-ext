load('config.js');

// Tab tu dat, luon dung dau, khong phu thuoc menu cua site.
// /last.html chay bang update.js chu khong phai list.js vi no can doc them so chuong
// o moi dong de loc theo MIN_CHAPTERS.
function pinned() {
    return {title: "Truyện mới cập nhật", input: "/last.html", script: "update.js"};
}

// Cac tab tinh du phong, dung khi khong doc duoc menu tren trang chu
function fallback() {
    return [
        pinned(),
        {title: "新书推荐", input: "/", script: "list.js"}
    ];
}

function execute() {
    let doc = getDoc('/');
    if (!doc) {
        return Response.success(fallback());
    }

    let tabs = [];
    let featured = null;
    let seen = {};
    // 'jilu' = 阅读记录 (lich su doc), 'newmessage' = 意见反馈 (phan hoi):
    // trang tai khoan, khong phai danh sach truyen -> mo ra la loi.
    let skip = ['login', 'register', 'reg.php', 'bookcase', 'user', 'logout',
                'javascript', 'mailto', '#', 'help', 'about',
                'jilu', 'newmessage'];

    doc.select('a').forEach(e => {
        if (tabs.length >= 9) {
            return;
        }
        let href = e.attr('href');
        let title = e.text();
        if (!href || !title) {
            return;
        }
        title = title.trim();
        if (title.length === 0 || title.length > 8) {
            return;
        }

        let low = href.toLowerCase();
        for (let i = 0; i < skip.length; i++) {
            if (low.indexOf(skip[i]) !== -1) {
                return;
            }
        }
        if (/\/(txt|book)\//.test(href)) {
            return;
        }
        if (href.indexOf('http') === 0 && href.indexOf('69') === -1) {
            return;
        }
        if (href === '/' || href.length < 2) {
            return;
        }
        if (seen[href]) {
            return;
        }
        seen[href] = true;

        let tab = {title: title, input: href, script: "list.js"};

        // Tab de cu / truyen moi duoc dua len dau tien
        if (!featured && (title.indexOf('推荐') !== -1 || title.indexOf('新书') !== -1
                || title.indexOf('最新') !== -1)) {
            featured = tab;
            return;
        }

        tabs.push(tab);
    });

    if (featured) {
        tabs.unshift(featured);
        tabs.push({title: "首页", input: "/", script: "list.js"});
    } else {
        tabs.unshift({title: "新书推荐", input: "/", script: "list.js"});
    }

    // Tab tu dat luon dung dau
    tabs.unshift(pinned());

    // Bo tab trung: trung ten (site co hai link cung tro ve trang chu), va trung dich
    // (menu site cung co 最新更新 -> /last.html, dung dich voi tab tu dat o tren).
    // Tab tu dat da unshift len dau nen no luon thang, ban khong loc bi bo.
    let out = [];
    let seenTitle = {};
    let seenInput = {};
    tabs.forEach(t => {
        let key = abs(t.input);
        if (seenTitle[t.title] || seenInput[key]) {
            return;
        }
        seenTitle[t.title] = true;
        seenInput[key] = true;
        out.push(t);
    });

    return Response.success(out);
}
