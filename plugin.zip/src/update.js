load('config.js');

// Tab "Truyen moi cap nhat" -> /last.html
//
// Cau truc that, doc thang tu DOM 2026-09-05:
//   div.recentupdate2 > ul > li
//       <a href="/book/<id>.htm">ten truyen</a>
//       <a href="/txt/<id>/<chap>">第1069章 ...</a>   <- SO CHUONG nam o day
//       <span>2025-10-23</span>
//
// Nho vay loc duoc theo so chuong ma KHONG ton them request nao. Neu phai mo tung
// truyen de dem chuong thi 30 truyen = 30 request, dung kieu da tung bi chan IP.
//
// Hai gioi han cua trang nay (da do, khong phai suy doan):
//   - khong co anh bia -> cover luon rong
//   - khong co phan trang -> dung 30 dong, khong hon
let ROW_SELECTOR = '.recentupdate2 ul li';

// MIN_CHAPTERS duoc vBook tiem vao thanh const tu plugin.json.config.
// Gia tri LUON la chuoi, va co the chua ton tai -> doc phong thu.
// Tuyet doi khong duoc `let MIN_CHAPTERS` o bat cu dau: trung ten voi const duoc tiem
// la SyntaxError, chet ca script.
function minChapters() {
    let raw = '';
    try {
        raw = MIN_CHAPTERS;
    } catch (e) {
        raw = '';
    }
    let n = parseInt(raw, 10);
    if (isNaN(n) || n < 0) {
        return 0;
    }
    return n;
}

// "第1069章 ..." -> 1069. Tra ve -1 neu khong doc duoc so.
// Day la so chuong MOI NHAT, khong phai tong so chuong - thuong bang nhau hoac
// chenh vai chuong (番外, 序章, danh so cach quang).
function chapterNo(text) {
    if (!text) {
        return -1;
    }
    let m = text.match(/第\s*(\d+)\s*章/);
    if (m) {
        return parseInt(m[1], 10);
    }
    // Vai truyen danh kieu "306.第306章 ..." - bat luon so dung dau
    m = text.match(/^\s*(\d+)\s*[.、]/);
    return m ? parseInt(m[1], 10) : -1;
}

function execute(url, page) {
    let target = page ? page : (url ? url : '/last.html');

    let doc = getDoc(target);
    if (!doc) {
        return Response.error('[update] Không tải được: ' + abs(target));
    }

    let rows = doc.select(ROW_SELECTOR);
    if (rows.size() === 0) {
        return Response.error('[update] Không thấy dòng nào khớp "' + ROW_SELECTOR
            + '". Site có thể đã đổi cấu trúc: ' + abs(target));
    }

    let min = minChapters();
    let books = [];
    let tooShort = 0;
    let unknown = 0;
    let seen = {};

    rows.forEach(e => {
        let bookSel = e.select('a[href*="/book/"]');
        let href = bookSel.attr('href');
        let name = bookSel.text();
        if (!href || !name) {
            return;
        }
        name = name.trim();
        if (name.length === 0) {
            return;
        }

        let m = href.match(/\/book\/(\d+)/);
        if (!m || seen[m[1]]) {
            return;
        }
        seen[m[1]] = true;

        let chapText = e.select('a[href*="/txt/"]').text();
        let no = chapterNo(chapText);

        // Dang loc ma khong doc duoc so -> loai, vi khong chung minh duoc la du chuong.
        if (min > 0) {
            if (no < 0) {
                unknown++;
                return;
            }
            if (no < min) {
                tooShort++;
                return;
            }
        }

        let desc = no > 0 ? (no + ' chương') : 'chưa rõ số chương';
        let date = e.select('span').text();
        if (date && date.trim().length > 0) {
            desc = desc + ' · ' + date.trim();
        }

        books.push({
            name: name,
            link: BASE_URL + '/book/' + m[1] + '.htm',
            host: BASE_URL,
            cover: '',
            description: desc
        });
    });

    console.log('[update] ' + books.length + '/' + rows.size() + ' truyện'
        + (min > 0 ? ' (lọc >=' + min + ' chương, bỏ ' + tooShort + ' ngắn, '
                     + unknown + ' không rõ)' : ' (không lọc)'));

    if (books.length === 0) {
        return Response.error('[update] Không truyện nào đạt >=' + min + ' chương. '
            + 'Trang này chỉ có ' + rows.size() + ' truyện — thử hạ ngưỡng trong cài đặt extension.');
    }

    return Response.success(books);
}
