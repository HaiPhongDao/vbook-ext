load('config.js');

// Dung bien o cap file thay vi ham long nhau - mot so ban vBook xu ly
// function khai bao ben trong execute() khong on dinh.
let BEST = [];
let TRIED = [];
let BOOK_ID = '';

function collect(doc, id) {
    let chapters = [];
    let seen = {};

    doc.select('a').forEach(e => {
        let href = e.attr('href');
        let name = e.text();
        if (!href || !name) {
            return;
        }
        name = name.trim();
        if (name.length === 0 || href.indexOf('end.html') !== -1) {
            return;
        }
        if (!/\/txt\/\d+\/\d+/.test(href)) {
            return;
        }
        if (id && href.indexOf('/txt/' + id + '/') === -1) {
            return;
        }
        if (seen[href]) {
            return;
        }
        seen[href] = true;
        chapters.push({name: name, url: abs(href), host: BASE_URL});
    });

    return chapters;
}

function findCatalogLink(doc) {
    let found = null;
    doc.select('a').forEach(e => {
        if (found) {
            return;
        }
        let t = e.text();
        let href = e.attr('href');
        if (!t || !href) {
            return;
        }
        if (t.indexOf('目录') !== -1 || t.indexOf('全部章节') !== -1 ||
            t.indexOf('章节列表') !== -1 || t.indexOf('查看全部') !== -1) {
            found = href;
        }
    });
    return found;
}

function attempt(path) {
    if (!path) {
        return null;
    }
    if (TRIED.indexOf(path) !== -1) {
        return null;
    }
    TRIED.push(path);

    let doc = getDoc(path);
    if (!doc) {
        return null;
    }

    let chapters = collect(doc, BOOK_ID);
    if (chapters.length === 0) {
        chapters = collect(doc, null);
    }
    if (chapters.length > BEST.length) {
        BEST = chapters;
    }
    return doc;
}

function run(url) {
    BOOK_ID = bookId(url);
    if (!BOOK_ID) {
        return Response.error('[toc] Không tách được ID từ: ' + url);
    }

    let info = attempt('/book/' + BOOK_ID + '.htm');

    if (info && BEST.length <= 20) {
        attempt(findCatalogLink(info));
    }

    if (BEST.length <= 20) {
        attempt('/txt/' + BOOK_ID + '/');
    }

    if (BEST.length > 0) {
        return Response.success(BEST);
    }

    return Response.error('[toc] Không thấy chương nào. HTTP ' + LAST_STATUS
        + '. Đã thử: ' + TRIED.join(' | '));
}

function execute(url) {
    try {
        return run(url);
    } catch (error) {
        // Bat loi de vBook khong nuot mat thong bao
        let msg = '';
        try {
            msg = '' + error;
        } catch (e2) {
            msg = 'không đọc được nội dung lỗi';
        }
        let where = '';
        try {
            where = ' | đã thử: ' + TRIED.join(' , ') + ' | lấy được: ' + BEST.length + ' chương';
        } catch (e3) {
        }
        return Response.error('[toc] LỖI SCRIPT: ' + msg + where);
    }
}
