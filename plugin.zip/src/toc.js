load('config.js');

function execute(url) {
    let id = bookId(url);
    if (!id) {
        return Response.error('Không nhận diện được ID truyện từ: ' + url);
    }

    // Muc luc nam o /txt/<id>/ chu khong phai /book/<id>.htm
    let doc = getDoc('/txt/' + id + '/');
    if (!doc) {
        return Response.error('Không tải được mục lục.');
    }

    let chapters = [];
    let seen = {};

    // Chi lay link chuong cua dung bo truyen nay
    doc.select('a[href*="/txt/' + id + '/"]').forEach(e => {
        let href = e.attr('href');
        let name = e.text();
        if (!href || !name) {
            return;
        }
        name = name.trim();
        if (name.length === 0) {
            return;
        }
        // Bo link dieu huong: end.html, trang chu, link lap
        if (href.indexOf('end.html') !== -1) {
            return;
        }
        if (!/\/txt\/\d+\/\d+/.test(href)) {
            return;
        }
        if (seen[href]) {
            return;
        }
        seen[href] = true;
        chapters.push({
            name: name,
            url: abs(href),
            host: BASE_URL
        });
    });

    if (chapters.length === 0) {
        return Response.error('Không tìm thấy chương nào. Site có thể đã đổi cấu trúc mục lục.');
    }

    return Response.success(chapters);
}
