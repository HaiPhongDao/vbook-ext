load('config.js');

function collect(doc, id) {
    let chapters = [];
    let seen = {};

    doc.select('a').forEach(e => {
        let href = e.attr('href');
        let name = e.text();
        if (!href || !name) {
            return;
        }
        name = name.trim();
        if (name.length === 0) {
            return;
        }
        if (href.indexOf('end.html') !== -1) {
            return;
        }
        // Chap link co dang /txt/<bookid>/<chapid>
        if (!/\/txt\/\d+\/\d+/.test(href)) {
            return;
        }
        // Neu biet ID truyen thi chi lay chuong cua dung bo do
        if (id && href.indexOf('/txt/' + id + '/') === -1) {
            return;
        }
        if (seen[href]) {
            return;
        }
        seen[href] = true;
        chapters.push({
            name: name,
            url: abs(href),
            host: BASE_URL
        });
    });

    return chapters;
}

// Khi khong tim thay chuong nao, tra ve mau href de biet trang thuc te trong nhu the nao
function sampleLinks(doc) {
    let out = [];
    doc.select('a').forEach(e => {
        if (out.length >= 8) {
            return;
        }
        let h = e.attr('href');
        if (h && h.length > 1 && h.indexOf('javascript') !== 0) {
            out.push(h);
        }
    });
    return out;
}

function execute(url) {
    let id = bookId(url);
    if (!id) {
        return Response.error('[toc] Không tách được ID từ: ' + url);
    }

    let tried = [];
    let candidates = [
        '/txt/' + id + '/',
        '/book/' + id + '.htm',
        '/' + id + '/'
    ];

    let lastDoc = null;
    let anchorTotal = 0;

    for (let i = 0; i < candidates.length; i++) {
        let doc = getDoc(candidates[i]);
        tried.push(candidates[i]);
        if (!doc) {
            continue;
        }
        lastDoc = doc;
        anchorTotal = doc.select('a').size();

        let chapters = collect(doc, id);
        if (chapters.length === 0) {
            // Thu lai khong loc theo ID phong khi muc luc dung ID khac
            chapters = collect(doc, null);
        }
        if (chapters.length > 0) {
            return Response.success(chapters);
        }
    }

    let msg = '[toc] Không thấy chương. Đã thử: ' + tried.join(' | ');
    if (lastDoc) {
        msg += ' — số thẻ <a> trên trang: ' + anchorTotal;
        msg += ' — href mẫu: ' + sampleLinks(lastDoc).join(' , ');
    } else {
        msg += ' — không tải được trang nào (kiểm tra BASE_URL).';
    }
    return Response.error(msg);
}
