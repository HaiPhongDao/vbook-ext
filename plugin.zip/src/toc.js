load('config.js');

// Muc luc that nam o /book/<id>/ (co dau / cuoi, khong phai .htm).
// Toan bo chuong nam trong mot trang, khong phan trang - da do tren truyen 481 chuong.
let CATALOG_SELECTOR = '#catalog ul li a';

function collect(doc, id, selector) {
    let chapters = [];
    let seen = {};

    doc.select(selector).forEach(e => {
        let href = e.attr('href');
        let name = e.text();
        if (!href || !name) {
            return;
        }
        name = name.trim();
        if (name.length === 0 || href.indexOf('end.html') !== -1) {
            return;
        }
        if (!/\/txt\/\d+\/\d+/.test(href)) {
            return;
        }
        if (id && href.indexOf('/txt/' + id + '/') === -1) {
            return;
        }
        if (seen[href]) {
            return;
        }
        seen[href] = true;
        chapters.push({name: name, url: abs(href), host: BASE_URL});
    });

    return chapters;
}

// Thu selector hep truoc, noi rong dan neu site doi cau truc
function collectFrom(doc, id) {
    let chapters = collect(doc, id, CATALOG_SELECTOR);
    if (chapters.length === 0) {
        chapters = collect(doc, id, 'a');
    }
    if (chapters.length === 0) {
        chapters = collect(doc, null, 'a');
    }
    return chapters;
}

// Tim link muc luc ngay tren trang thong tin truyen.
// Chi dung khi /book/<id>/ that bai - vi du site doi duong dan.
function findCatalogLink(doc) {
    let found = null;

    // Nut 完整目录 tren /book/<id>.htm la a.btn.more-btn (trong div.mybox)
    doc.select('a.btn.more-btn').forEach(e => {
        if (found) {
            return;
        }
        let href = e.attr('href');
        if (href) {
            found = href;
        }
    });
    if (found) {
        return found;
    }

    // Du phong: so khop chu, phong khi site doi class
    doc.select('a').forEach(e => {
        if (found) {
            return;
        }
        let t = e.text();
        let href = e.attr('href');
        if (!t || !href) {
            return;
        }
        if (t.indexOf('完整目录') !== -1 || t.indexOf('目录') !== -1 ||
            t.indexOf('全部章节') !== -1 || t.indexOf('章节列表') !== -1 ||
            t.indexOf('查看全部') !== -1) {
            found = href;
        }
    });

    return found;
}

// Trang thong tin xep chuong moi nhat len dau, trang muc luc that thi xep xuoi.
// Dua vao chapid trong /txt/<bookid>/<chapid> - so nay tang dan theo thu tu ra chuong.
function chapNum(u) {
    let m = u.match(/\/txt\/\d+\/(\d+)/);
    return m ? parseInt(m[1], 10) : -1;
}

function fixOrder(chapters) {
    if (chapters.length < 2) {
        return chapters;
    }

    let up = 0;
    let down = 0;
    for (let i = 1; i < chapters.length; i++) {
        let a = chapNum(chapters[i - 1].url);
        let b = chapNum(chapters[i].url);
        if (a < 0 || b < 0 || a === b) {
            continue;
        }
        if (b > a) {
            up++;
        } else {
            down++;
        }
    }

    // Phan lon cap lien tiep giam dan -> danh sach dang xep nguoc
    if (down > up) {
        let out = [];
        for (let i = chapters.length - 1; i >= 0; i--) {
            out.push(chapters[i]);
        }
        return out;
    }

    return chapters;
}

function loadPage(path, id, tried) {
    tried.push(path);
    let doc = getDoc(path);
    if (!doc) {
        return [];
    }
    return collectFrom(doc, id);
}

function alreadyTried(path, tried) {
    let full = abs(path);
    for (let i = 0; i < tried.length; i++) {
        if (abs(tried[i]) === full) {
            return true;
        }
    }
    return false;
}

function finish(chapters, from) {
    chapters = fixOrder(chapters);
    console.log('[toc] ' + chapters.length + ' chương từ ' + from);
    return Response.success(chapters);
}

function execute(url) {
    let id = bookId(url);
    if (!id) {
        return Response.error('[toc] Không tách được ID từ: ' + url);
    }

    let tocPath = '/book/' + id + '/';
    let infoPath = '/book/' + id + '.htm';
    let tried = [];

    // 1. Muc luc that - truong hop binh thuong, dung o day.
    let chapters = loadPage(tocPath, id, tried);
    if (chapters.length > 0) {
        return finish(chapters, tocPath);
    }

    // 2. Phuong an chot: trang thong tin.
    let info = getDoc(infoPath);
    tried.push(infoPath);
    if (!info) {
        return Response.error('[toc] Không tải được trang nào. Đã thử: ' + tried.join(' | '));
    }

    // Neu site doi duong dan muc luc thi di theo link tren trang thong tin.
    let cat = findCatalogLink(info);
    if (cat && !alreadyTried(cat, tried)) {
        chapters = loadPage(cat, id, tried);
        if (chapters.length > 0) {
            return finish(chapters, cat);
        }
    }

    // Cuoi cung: ~5 chuong moi nhat tren chinh trang thong tin (xep nguoc, fixOrder lo).
    chapters = collectFrom(info, id);
    if (chapters.length > 0) {
        return finish(chapters, infoPath);
    }

    return Response.error('[toc] Không thấy chương. Đã thử: ' + tried.join(' | '));
}
