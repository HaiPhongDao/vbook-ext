load('config.js');

function collect(doc, id) {
    let chapters = [];
    let seen = {};

    doc.select('a').forEach(e => {
        let href = e.attr('href');
        let name = e.text();
        if (!href || !name) {
            return;
        }
        name = name.trim();
        if (name.length === 0 || href.indexOf('end.html') !== -1) {
            return;
        }
        if (!/\/txt\/\d+\/\d+/.test(href)) {
            return;
        }
        if (id && href.indexOf('/txt/' + id + '/') === -1) {
            return;
        }
        if (seen[href]) {
            return;
        }
        seen[href] = true;
        chapters.push({name: name, url: abs(href), host: BASE_URL});
    });

    return chapters;
}

// Tim link "muc luc / xem toan bo chuong" ngay tren trang thong tin truyen
function findCatalogLink(doc, id) {
    let found = null;
    doc.select('a').forEach(e => {
        if (found) {
            return;
        }
        let t = e.text();
        let href = e.attr('href');
        if (!t || !href) {
            return;
        }
        if (t.indexOf('目录') !== -1 || t.indexOf('全部章节') !== -1 ||
            t.indexOf('章节列表') !== -1 || t.indexOf('查看全部') !== -1) {
            found = href;
        }
    });
    return found;
}

function execute(url) {
    let id = bookId(url);
    if (!id) {
        return Response.error('[toc] Không tách được ID từ: ' + url);
    }

    let best = [];
    let bestFrom = '';
    let tried = [];
    let loaded = 0;

    function attempt(path) {
        if (!path) {
            return;
        }
        tried.push(path);
        let doc = getDoc(path);
        if (!doc) {
            return;
        }
        loaded++;
        let chapters = collect(doc, id);
        if (chapters.length === 0) {
            chapters = collect(doc, null);
        }
        if (chapters.length > best.length) {
            best = chapters;
            bestFrom = path;
        }
        return doc;
    }

    // 1. Duong dan muc luc thong thuong - truong hop tot nhat chi ton 1 request
    attempt('/txt/' + id + '/');
    if (best.length > 20) {
        console.log('[toc] ' + best.length + ' chương từ ' + bestFrom);
        return Response.success(best);
    }

    // 2. Hoi chinh trang thong tin xem muc luc nam dau
    let info = attempt('/book/' + id + '.htm');
    if (info) {
        let cat = findCatalogLink(info, id);
        if (cat && tried.indexOf(cat) === -1) {
            attempt(cat);
        }
    }

    if (best.length > 0) {
        console.log('[toc] ' + best.length + ' chương từ ' + bestFrom);
        return Response.success(best);
    }

    if (loaded === 0) {
        return Response.error('[toc] Không vào được 69shuba. HTTP ' + LAST_STATUS
            + '. Đã thử fetch, browser engine và các domain dự phòng.');
    }

    return Response.error('[toc] Tải được trang nhưng không thấy chương. Đã thử: ' + tried.join(' | '));
}
