load('config.js');

function collect(doc, id) {
    let chapters = [];
    let seen = {};

    doc.select('a').forEach(e => {
        let href = e.attr('href');
        let name = e.text();
        if (!href || !name) {
            return;
        }
        name = name.trim();
        if (name.length === 0 || href.indexOf('end.html') !== -1) {
            return;
        }
        if (!/\/txt\/\d+\/\d+/.test(href)) {
            return;
        }
        if (id && href.indexOf('/txt/' + id + '/') === -1) {
            return;
        }
        if (seen[href]) {
            return;
        }
        seen[href] = true;
        chapters.push({name: name, url: abs(href), host: BASE_URL});
    });

    return chapters;
}

// Tim link "muc luc / xem toan bo chuong" ngay tren trang thong tin truyen
function findCatalogLink(doc, id) {
    let found = null;
    doc.select('a').forEach(e => {
        if (found) {
            return;
        }
        let t = e.text();
        let href = e.attr('href');
        if (!t || !href) {
            return;
        }
        if (t.indexOf('目录') !== -1 || t.indexOf('全部章节') !== -1 ||
            t.indexOf('章节列表') !== -1 || t.indexOf('查看全部') !== -1) {
            found = href;
        }
    });
    return found;
}

function execute(url) {
    let id = bookId(url);
    if (!id) {
        return Response.error('[toc] Không tách được ID từ: ' + url);
    }

    let candidates = ['/txt/' + id + '/', '/book/' + id + '/', '/txt/' + id + '/index.html'];

    // Doc trang thong tin de lay link muc lux that su, uu tien no
    let info = getDoc('/book/' + id + '.htm');
    if (info) {
        let cat = findCatalogLink(info, id);
        if (cat) {
            candidates.unshift(cat);
        }
    }
    // Trang thong tin chi co ~5 chuong moi nhat -> de cuoi cung lam phuong an chot
    candidates.push('/book/' + id + '.htm');

    // Lay danh sach DAI NHAT chu khong phai cai dau tien tim thay
    let best = [];
    let bestFrom = '';
    let tried = [];

    for (let i = 0; i < candidates.length; i++) {
        tried.push(candidates[i]);
        let doc = getDoc(candidates[i]);
        if (!doc) {
            continue;
        }
        let chapters = collect(doc, id);
        if (chapters.length === 0) {
            chapters = collect(doc, null);
        }
        if (chapters.length > best.length) {
            best = chapters;
            bestFrom = candidates[i];
        }
        // Muc luc that su luon nhieu hon vai chuong
        if (best.length > 50) {
            break;
        }
    }

    if (best.length > 0) {
        console.log('[toc] ' + best.length + ' chương từ ' + bestFrom);
        return Response.success(best);
    }

    return Response.error('[toc] Không thấy chương. Đã thử: ' + tried.join(' | '));
}
