load('config.js');

function collect(doc, id) {
    let chapters = [];
    let seen = {};

    doc.select('a').forEach(e => {
        let href = e.attr('href');
        let name = e.text();
        if (!href || !name) {
            return;
        }
        name = name.trim();
        if (name.length === 0 || href.indexOf('end.html') !== -1) {
            return;
        }
        if (!/\/txt\/\d+\/\d+/.test(href)) {
            return;
        }
        if (id && href.indexOf('/txt/' + id + '/') === -1) {
            return;
        }
        if (seen[href]) {
            return;
        }
        seen[href] = true;
        chapters.push({name: name, url: abs(href), host: BASE_URL});
    });

    return chapters;
}

function findCatalogLink(doc) {
    let found = null;
    doc.select('a').forEach(e => {
        if (found) {
            return;
        }
        let t = e.text();
        let href = e.attr('href');
        if (!t || !href) {
            return;
        }
        if (t.indexOf('目录') !== -1 || t.indexOf('全部章节') !== -1 ||
            t.indexOf('章节列表') !== -1 || t.indexOf('查看全部') !== -1 ||
            t.indexOf('开始阅读') !== -1) {
            found = href;
        }
    });
    return found;
}

function execute(url) {
    let id = bookId(url);
    if (!id) {
        return Response.error('[toc] Không tách được ID từ: ' + url);
    }

    let best = [];
    let bestFrom = '';
    let tried = [];

    function attempt(path) {
        if (!path || tried.indexOf(path) !== -1) {
            return null;
        }
        tried.push(path);
        let doc = getDoc(path);
        if (!doc) {
            return null;
        }
        let chapters = collect(doc, id);
        if (chapters.length === 0) {
            chapters = collect(doc, null);
        }
        if (chapters.length > best.length) {
            best = chapters;
            bestFrom = path;
        }
        return doc;
    }

    // 1. Trang thong tin - da biet chac la tai duoc (phan Gioi thieu hien binh thuong).
    //    Vua lay duoc vai chuong moi nhat, vua tim ra link muc luc that.
    let info = attempt('/book/' + id + '.htm');

    // 2. Di theo dung link muc luc ma site chi ra
    if (info && best.length <= 20) {
        attempt(findCatalogLink(info));
    }

    // 3. Chi khi hai buoc tren that bai moi do duong dan
    if (best.length <= 20) {
        attempt('/txt/' + id + '/');
    }

    if (best.length > 0) {
        return Response.success(best);
    }

    return Response.error('[toc] Không thấy chương nào. HTTP ' + LAST_STATUS
        + '. Đã thử: ' + tried.join(' | '));
}
