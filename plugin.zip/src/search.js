load('config.js');

// Form tim kiem that tren trang chu (doc truc tiep tu DOM 2026-09-05):
//   <form name="articlesearch" method="post" action="/modules/article/search.php">
//     <input type="text" name="searchkey" class="search-input">
//     <button type="submit" name="submit" value="Search">
// => POST, khong phai GET. Chi co mot field 'searchkey'. KHONG co 'searchtype'.
//
// LUU Y bang ma: site la GBK, nen ve nguyen tac searchkey phai percent-encode theo
// GBK (vi du 反馈 -> %B7%B4%C0%A1, thay trong chinh link cua site), con
// encodeURIComponent() cua JS chi ra UTF-8. Chua lam bo ma hoa GBK vi endpoint hien
// bo qua input hoan toan (xem NOTES), khong co cach nao kiem chung. Neu sau nay search
// song lai ma van rong, day la thu can thu tiep.
function execute(key, page) {
    let doc = postDoc('/modules/article/search.php',
                      'searchkey=' + encodeURIComponent(key) + '&submit=Search');
    if (!doc) {
        return Response.error('[search] Không gọi được endpoint tìm kiếm.');
    }

    let books = parseList(doc);

    // Da do: endpoint tra ve trang khung 7283 byte y het nhau cho MOI tu khoa, ke ca
    // tu khoa rong. Tra ve mang rong se hien thanh "khong tim thay" - nguoi dung tuong
    // minh go sai. Bao loi ro rang thi dung hon.
    if (books.length === 0) {
        return Response.error('[search] Site trả về trang rỗng cho mọi từ khoá. '
            + 'Tìm kiếm phía server đang hỏng, hoặc IP bị chặn tạm thời — thử lại sau 10-15 phút.');
    }

    return Response.success(books);
}
