load('config.js');

function execute(key, page) {
    let doc = getDoc('/modules/article/search.php?searchkey=' + encodeURIComponent(key) + '&searchtype=all');
    if (!doc) {
        doc = getDoc('/search/?searchkey=' + encodeURIComponent(key));
    }
    if (!doc) {
        return Response.error('[search] Không tìm kiếm được. Site có thể đã đổi domain.');
    }

    let books = parseList(doc);
    return Response.success(books);
}
