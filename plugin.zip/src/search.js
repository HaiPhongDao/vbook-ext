load('config.js');

function execute(key, page) {
    // 69shuba chay tren ma nguon Jieqi CMS -> endpoint search.php
    let doc = getDoc('/modules/article/search.php?searchkey=' + encodeURIComponent(key) + '&searchtype=all');

    // Neu endpoint tren doi, thu duong /search/
    if (!doc) {
        doc = getDoc('/search/?searchkey=' + encodeURIComponent(key));
    }
    if (!doc) {
        return Response.error('Không tìm kiếm được. Site có thể đã đổi domain — sửa BASE_URL trong config.js.');
    }

    let books = parseList(doc);

    // Truong hop tim thay dung 1 truyen, site redirect thang sang trang truyen
    if (books.length === 0) {
        let id = bookId(doc.select('link[rel=canonical]').attr('href') || '');
        if (id) {
            books.push({
                name: pickText(doc, ['.booknav2 h1 a', '.booknav2 h1', 'h1']),
                link: BASE_URL + '/book/' + id + '.htm',
                host: BASE_URL
            });
        }
    }

    return Response.success(books);
}
