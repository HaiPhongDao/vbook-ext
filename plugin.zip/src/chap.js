load('config.js');

function execute(url) {
    let doc = getDoc(url);
    if (!doc) {
        return Response.error('Không tải được nội dung chương.');
    }

    // Don rac truoc khi lay noi dung
    doc.select('.txtinfo').remove();
    doc.select('#txtright').remove();
    doc.select('.err_tips').remove();
    doc.select('.page1').remove();
    doc.select('.bottom-ad').remove();
    doc.select('h1').remove();
    doc.select('script').remove();
    doc.select('style').remove();
    doc.select('ins').remove();
    doc.select('iframe').remove();

    let htm = doc.select('.txtnav').html();
    if (!htm) {
        htm = doc.select('#content').html();
    }
    if (!htm) {
        return Response.error('Không tìm thấy nội dung chương (.txtnav).');
    }

    htm = htm.replace(/&nbsp;/g, '');
    // Xoa watermark ten site chen giua text
    htm = htm.replace(/69书吧/g, '');
    htm = htm.replace(/(69shuba|69shu|69shux|69xinshu)\s*[\.．]\s*(com|pro|top|cx|me)/gi, '');
    htm = htm.replace(/请记住本书首发域名[^<]*/g, '');
    htm = htm.replace(/(www[\.．])?(69shuba|69shux)[^<\s]*/gi, '');

    return Response.success(htm);
}
