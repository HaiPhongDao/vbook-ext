load('config.js');

// Tach noi dung thanh tung doan van ban thuan
function splitParas(htm) {
    let raw = htm.split(/<\s*br\s*\/?\s*>|<\/\s*p\s*>|<\s*p[^>]*>|<\/\s*div\s*>/i);
    let out = [];
    for (let i = 0; i < raw.length; i++) {
        let t = raw[i];
        if (!t) {
            continue;
        }
        t = t.replace(/<[^>]+>/g, '');
        t = t.replace(/&nbsp;/g, ' ');
        t = t.replace(/\s+/g, ' ');
        t = t.trim();
        if (t.length > 0) {
            out.push(t);
        }
    }
    return out;
}

// Gop doan ngan lai cho du dai, giam so luot doc cua TTS
function mergeParas(paras, minLen) {
    let out = [];
    let buf = '';
    for (let i = 0; i < paras.length; i++) {
        buf = buf.length === 0 ? paras[i] : buf + ' ' + paras[i];
        if (buf.length >= minLen) {
            out.push(buf);
            buf = '';
        }
    }
    if (buf.length > 0) {
        out.push(buf);
    }
    return out;
}

function execute(url) {
    let doc = getDoc(url);
    if (!doc) {
        return Response.error('Không tải được nội dung chương.');
    }

    doc.select('.txtinfo').remove();
    doc.select('#txtright').remove();
    doc.select('.err_tips').remove();
    doc.select('.page1').remove();
    doc.select('.bottom-ad').remove();
    doc.select('h1').remove();
    doc.select('script').remove();
    doc.select('style').remove();
    doc.select('ins').remove();
    doc.select('iframe').remove();

    let htm = doc.select('.txtnav').html();
    if (!htm) {
        htm = doc.select('#content').html();
    }
    if (!htm) {
        return Response.error('Không tìm thấy nội dung chương (.txtnav).');
    }

    htm = htm.replace(/&nbsp;/g, '');
    htm = htm.replace(/69书吧/g, '');
    htm = htm.replace(/(69shuba|69shu|69shux|69xinshu)\s*[\.．]\s*(com|pro|top|cx|me)/gi, '');
    htm = htm.replace(/请记住本书首发域名[^<]*/g, '');

    if (MERGE_MIN > 0) {
        let paras = mergeParas(splitParas(htm), MERGE_MIN);
        let built = '';
        for (let i = 0; i < paras.length; i++) {
            let t = paras[i];
            if (PARA_PAUSE > 0) {
                for (let k = 0; k < PARA_PAUSE; k++) {
                    t += '…';
                }
            }
            built += '<p>' + t + '</p>';
        }
        if (built.length > 0) {
            htm = built;
        }
    }

    return Response.success(htm);
}
